import React from 'react';
import './App.css';
import { Route, BrowserRouter as Router, Link } from 'react-router-dom'
import Create from './components/create';
import Delete from './components/delete';
import Update from './components/update';
import Read from './components/read';

function App() {
  return (
    <div className="app">
      <Router>
        <div>
          <ul>
            <li><Link to="/">Create</Link></li>
            <li><Link to="/delete">Delete</Link></li>
            <li><Link to="/update">Update</Link></li>
            <li><Link to="/read">Users</Link></li>
          </ul>
          <Route exact path='/' component={Create}/>
          <Route  path='/delete' component={Delete}/>
          <Route  path='/update' component={Update}/>
          <Route  path='/read' component={Read}/>
        </div>
      </Router>
    </div>
  );
}

export default App;
