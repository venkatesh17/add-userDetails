import React from "react";
import * as action from "../actions/create.js";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

class Create extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: "Movie",
      itemname: "",
      username:''
    };
  }
  // componentWillMount = () => {
  //   this.props.values.createUsers();
  // };

  // componentWillReceiveProps = nextProps => {};
  
 
  handleChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  };

  selectChange = e => {
    this.setState({
      value: e.target.value
    });
  };

  onclick = (e) => {
    e.preventDefault();
    this.props.values.createUsers(this.state.username, this.state.value, this.state.itemname);
    this.setState({
          username:'',
          value:"Movie",
          itemname:'', 
    })
  };

  render() {

    return (
      <div className="create">
        <h2>Please Provide the details</h2>
        <p>Please enter the Name</p>
        <input
          type="text"
          onChange={this.handleChange}
          name="username"
          value={this.state.username}
          placeholder="name"
        />
        <br />
        <p>Please select the option</p>
        <select onChange={this.selectChange} value={this.state.value}>
          <option value="Movie">Movie</option>
          <option value="Food">Food</option>
        </select>{" "}
        <br />
        <p> Please enter the Movie/Food Name</p>
        <input
          type="text"
          onChange={this.handleChange}
          name="itemname"
          value={this.state.itemname}
          placeholder="name"
        />
        <br />
        <br />
        <button onClick={this.onclick}>Submit</button>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  createReducer: state.createReducer
});

const mapDispathToProps = dispatch => ({
  values: bindActionCreators(action, dispatch)
});
export default connect(
  mapStateToProps,
  mapDispathToProps
)(Create);
