import React from 'react';

class Update extends React.Component {
    render(){
        return(
            <div>
                <p>Update</p>
            </div>
        )
    }
}
export default Update;