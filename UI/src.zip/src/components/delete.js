import React from 'react';

class Delete extends React.Component {
    render(){
        return(
            <div>
                <p>Delete</p>
            </div>
        )
    }
}
export default Delete;