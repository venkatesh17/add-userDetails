import React from 'react';
import * as action from "../actions/read.js"
import * as deleteaction from '../actions/delete'
import { bindActionCreators } from "redux";
import { connect } from 'react-redux';


class Read extends React.Component {
    constructor(props){
        super(props);
        this.state ={
           data:[]
        }
    }

    componentWillMount =() =>{
        console.log("componentWillMount");
        
       let userdate = this.props.values.getUsers();
       this.setState({
           data:userdate
       })
    
    }
    // componentWillReceiveProps =() =>{
    //     console.log("componentWillReceiveProps-------");

    //     this.props.values.getUsers();
    // }

    renderTableHeader() {
        let header = Object.keys(this.props.getUserValues.users.data ? this.props.getUserValues.users.data[0]:"")
        return header.map((key, index) => {
           return <th key={index}>{key.toUpperCase()}</th>
        })
     }
   
     onDelete =(id)=>{
        this.props.deleteuser.deleteuser(id); 
     }
    renderTableData=()=> {
        return this.props.getUserValues.users.data ? this.props.getUserValues.users.data.map((item, index) => {
           const { _id,Name, Type, Favorite, createdAt, updatedAt } = item //destructuring
           return (
              <tr key={_id}>
                <td>{_id}</td>
                 <td>{Name}</td>
                 <td>{Type}</td>
                 <td>{Favorite}</td>
                 <td>{createdAt}</td>
                 <td>{updatedAt}</td>
                 <td><button onClick={() => this.onDelete({_id})}>Delete</button></td>
              </tr>
           )
        }):"" 
     }

    render(){
           console.log("this...............",this.state.data)
        return(
            <div>
                <h1 id='title'>Displaying Users</h1>
                <table id='users'>
                    <tbody>
                        <tr>{this.renderTableHeader()}</tr>
                        {this.renderTableData()}
                    </tbody>
                </table>
         </div>
        )
    }
}

const mapStateToProps = state => ({
    getUserValues: state.getReducers,
    deleteuser: state.deleteReducers
})

const mapDispatchToProps = dispatch =>({
    values: bindActionCreators(action, dispatch),
    deleteuser : bindActionCreators(deleteaction, dispatch) 
})

export default connect(mapStateToProps, mapDispatchToProps)(Read);