import * as types from '../constants/create';
import axios from "axios";


export const createUserRequest = () =>{
    return {
        type: types.CREATE_REQUEST
    }
}

export const createUserSuccess = (users) => {
    return{
        type: types.CREATE_SUCCESS,
        payload: users
    }
}

export const createUserError = err => {
    return {
        type: types.CREATE_FAILURE,
        payload: err
    }
}

export const createUsers =(username, value, itemvalue)=>{
   
    return async function(dispatch){
               
        dispatch(createUserRequest())

        axios('http://localhost:4001/user', {
            method: 'POST',
            mode: 'no-cors',
            data:{
                Name: username,
                Type: value,
                Favorite: itemvalue
            },
            headers: {
              'Access-Control-Allow-Origin': 'No',
              'Content-Type': 'application/json',
            },
           
            credentials: 'same-origin',
          }).then(response=>{
                    const users = response.data
                    dispatch(createUserSuccess(users))
            }).catch(error=>{
                dispatch(createUserError(error.message))
            })
       
    }
} 