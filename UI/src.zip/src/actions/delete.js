import * as types from '../constants/delete';
import axios from 'axios';
import {getUsers} from './read'
export const deleteUserRequest  = ()=>{
    return {
        type: types.DELETE_USER_REQUEST
    }
}

export const deleteUserSuccess = (users)=>{
    return {
        type: types.DELETE_USER_SUCCESS,
        payload: users
    }
}

export const deleteUserFailure = err =>{
    return {
        type: types.DELETE_USER_FAILURE,
        payload: err
    }
}

export const deleteuser = (userid) =>{

    return async function(dispatch){
        dispatch(deleteUserRequest())

        await axios('http://localhost:4001/deleteuser',{
                method: "DELETE",
                mode: 'no-cors',
                data: {
                    userId:userid._id
                },
                headers: {
                        'Access-Control-Allow-Origin': 'No',
                        'Content-Type': 'application/json',
                },
                credentials: 'same-origin',
        }).then(response=>{
                const users = response.data;
                dispatch(deleteUserSuccess(users));
                dispatch(getUsers())
        }).catch(err=>{
                dispatch(deleteUserFailure(err.message))
        })
    }
}

